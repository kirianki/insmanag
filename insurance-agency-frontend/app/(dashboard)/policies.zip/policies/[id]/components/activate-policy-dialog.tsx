// app/(dashboard)/policies/[id]/components/activate-policy-dialog.tsx

'use client';

import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useMutation } from '@tanstack/react-query';
import { Policy } from '@/types/api';
import { activatePolicyEnhanced } from '@/services/policyService';
import { useToast } from '@/lib/hooks';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { CalendarIcon, Shield } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const activateSchema = z.object({
  insurance_certificate_number: z.string().min(1, 'Insurance certificate number is required'),
  policy_start_date: z.date().optional(),
  policy_end_date: z.date().optional(),
});

interface ActivatePolicyDialogProps {
  policy: Policy;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  onSuccess: () => void;
}

export function ActivatePolicyDialog({
  policy,
  isOpen,
  setIsOpen,
  onSuccess,
}: ActivatePolicyDialogProps) {
  const { toast } = useToast();

  const form = useForm<z.infer<typeof activateSchema>>({
    resolver: zodResolver(activateSchema),
    defaultValues: {
      insurance_certificate_number: policy.insurance_certificate_number || '',
      policy_start_date: policy.policy_start_date ? new Date(policy.policy_start_date) : undefined,
      policy_end_date: policy.policy_end_date ? new Date(policy.policy_end_date) : undefined,
    },
  });

  const mutation = useMutation({
    mutationFn: (data: z.infer<typeof activateSchema>) => {
      const payload = {
        insurance_certificate_number: data.insurance_certificate_number,
        ...(data.policy_start_date && {
          policy_start_date: format(data.policy_start_date, 'yyyy-MM-dd'),
        }),
        ...(data.policy_end_date && {
          policy_end_date: format(data.policy_end_date, 'yyyy-MM-dd'),
        }),
      };
      return activatePolicyEnhanced(policy.id, payload);
    },
    onSuccess: () => {
      toast.success('Policy Activated', {
        description: 'Policy has been successfully activated and is now active.',
      });
      setIsOpen(false);
      onSuccess();
    },
    onError: (error: any) => {
      console.error('Activation error:', error);
      toast.error('Activation Failed', {
        description: error.response?.data?.detail || 'Failed to activate policy. Please try again.',
      });
    },
  });

  const onSubmit = (data: z.infer<typeof activateSchema>) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Activate Policy
          </DialogTitle>
          <DialogDescription>
            Activate policy #{policy.policy_number} for {policy.customer_detail.name}. 
            This will generate the insurance certificate and make the policy active.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="insurance_certificate_number"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Insurance Certificate Number</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter certificate number" {...field} />
                  </FormControl>
                  <FormDescription>
                    This number will be used for the official insurance certificate.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="policy_start_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Start Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={'outline'}
                            className={cn(
                              'pl-3 text-left font-normal',
                              !field.value && 'text-muted-foreground'
                            )}
                          >
                            {field.value ? (
                              format(field.value, 'PPP')
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="policy_end_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>End Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={'outline'}
                            className={cn(
                              'pl-3 text-left font-normal',
                              !field.value && 'text-muted-foreground'
                            )}
                          >
                            {field.value ? (
                              format(field.value, 'PPP')
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsOpen(false)}
                disabled={mutation.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? 'Activating...' : 'Activate Policy'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}