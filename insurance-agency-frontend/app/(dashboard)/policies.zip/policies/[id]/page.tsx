// app/(dashboard)/policies/[id]/page.tsx

'use client';

import { PolicyDetailsClient } from './components/policy-details-client';
import { PageHeader } from '@/components/shared/PageHeader';
import { useParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { getPolicyById } from '@/services/policyService';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';

export default function PolicyPage() {
  const params = useParams();
  const policyId = params.id as string;

  const { data: policy, isLoading, error } = useQuery({
    queryKey: ['policy', policyId],
    queryFn: () => getPolicyById(policyId).then(res => res.data),
    // Don't retry on 401 errors
    retry: (failureCount, error: any) => {
      if (error?.response?.status === 401) return false;
      return failureCount < 2;
    },
  });

  if (isLoading) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-4 w-96" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  if (error) {
    const isUnauthorized = error?.response?.status === 401;
    
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <PageHeader title={isUnauthorized ? "Authentication Required" : "Policy Not Found"} />
        <div className="text-center py-8">
          <p className="text-destructive mb-4">
            {isUnauthorized 
              ? "Your session has expired. Please log in again."
              : "Unable to load policy details."
            }
          </p>
          <p className="text-sm text-muted-foreground mb-4">
            {isUnauthorized
              ? "The policy may not exist or you may not have permission to view it."
              : "The policy may not exist or you may not have permission to view it."
            }
          </p>
          {isUnauthorized && (
            <Button 
              onClick={() => window.location.href = '/login'}
              variant="default"
            >
              Go to Login
            </Button>
          )}
        </div>
      </div>
    );
  }

  if (!policy) {
    return (
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <PageHeader title="Policy Not Found" />
        <div className="text-center py-8">
          <p className="text-destructive mb-4">Policy not found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
      <PolicyDetailsClient policy={policy} />
   </div>
  );
}