'use client';

import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { PlusCircle, Filter, Search, Building, FileText, CreditCard } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import { getInsuranceProviders } from '@/services/policyService';
import { InsuranceProviderList } from '@/types/api';
import { useCurrentUser } from '@/lib/hooks';
import { Badge } from '@/components/ui/badge';

interface PoliciesToolbarProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  statusFilter: string;
  setStatusFilter: (value: string) => void;
  providerFilter: string;
  setProviderFilter: (value: string) => void;
  policyTypeFilter: string;
  setPolicyTypeFilter: (value: string) => void;
  installmentFilter: string;
  setInstallmentFilter: (value: string) => void;
  hasVehicleRegOnly?: boolean;
  setHasVehicleRegOnly?: (value: boolean) => void;
  onCreateClick: () => void;
}

// Use null instead of empty string for "all" options
const statusOptions = [
  { value: 'all', label: 'All Statuses' },
  { value: 'AWAITING_PAYMENT', label: 'Awaiting Payment' },
  { value: 'PAID_PENDING_ACTIVATION', label: 'Pending Activation' },
  { value: 'ACTIVE', label: 'Active' },
  { value: 'ACTIVE_INSTALLMENT', label: 'Active (Installment)' },
  { value: 'EXPIRED', label: 'Expired' },
  { value: 'CANCELLED', label: 'Cancelled' },
  { value: 'LAPSED', label: 'Lapsed' },
];

const installmentOptions = [
  { value: 'all', label: 'All Payment Types' },
  { value: 'installment', label: 'Installment Plans' },
  { value: 'full', label: 'Full Payment' },
];

export function PoliciesToolbar({
  searchTerm,
  setSearchTerm,
  statusFilter,
  setStatusFilter,
  providerFilter,
  setProviderFilter,
  policyTypeFilter,
  setPolicyTypeFilter,
  installmentFilter,
  setInstallmentFilter,
  hasVehicleRegOnly,
  setHasVehicleRegOnly,
  onCreateClick
}: PoliciesToolbarProps) {
  const { user } = useCurrentUser();

  // Fetch insurance providers for dropdown
  const { data: providersData } = useQuery({
    queryKey: ['insurance-providers'],
    queryFn: () => getInsuranceProviders({ is_active: true }),
    enabled: !!user,
  });

  const providers: InsuranceProviderList[] = Array.isArray((providersData as any)?.data?.results)
    ? ((providersData as any).data.results as InsuranceProviderList[])
    : Array.isArray((providersData as any)?.data)
    ? ((providersData as any).data as InsuranceProviderList[])
    : [];

  // Clear all filters
  const clearAllFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setProviderFilter('all');
    setPolicyTypeFilter('all');
    setInstallmentFilter('all');
  };

  const hasActiveFilters = searchTerm ||
    (statusFilter && statusFilter !== 'all') ||
    (providerFilter && providerFilter !== 'all') ||
    (policyTypeFilter && policyTypeFilter !== 'all') ||
    (installmentFilter && installmentFilter !== 'all') ||
    hasVehicleRegOnly;

  return (
    <div className="space-y-4">
      {/* Main toolbar row */}
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        <div className="flex flex-1 flex-col sm:flex-row gap-3 w-full lg:w-auto">
          {/* Search */}
          <div className="relative max-w-sm">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search policies..."
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              className="h-9 pl-8 w-full"
            />
          </div>

          {/* Status Filter */}
          <Select value={statusFilter || 'all'} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Provider Filter */}
          <Select value={providerFilter || 'all'} onValueChange={setProviderFilter}>
            <SelectTrigger className="h-9 w-[180px]">
              <Building className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Provider" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Providers</SelectItem>
              {providers.map(provider => (
                <SelectItem key={provider.id} value={provider.id}>
                  {provider.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Installment Filter */}
          <Select value={installmentFilter || 'all'} onValueChange={setInstallmentFilter}>
            <SelectTrigger className="h-9 w-[180px]">
              <CreditCard className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Payment Type" />
            </SelectTrigger>
            <SelectContent>
              {installmentOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Has Vehicle Reg toggle */}
          {typeof hasVehicleRegOnly === 'boolean' && typeof setHasVehicleRegOnly === 'function' && (
            <Button
              type="button"
              variant={hasVehicleRegOnly ? 'default' : 'outline'}
              className="h-9"
              onClick={() => setHasVehicleRegOnly(!hasVehicleRegOnly)}
            >
              <FileText className="h-4 w-4 mr-2" />
              Has Vehicle Reg
            </Button>
          )}
        </div>

        <div className="flex items-center gap-2 w-full lg:w-auto">
          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearAllFilters}
              className="h-9"
            >
              Clear Filters
            </Button>
          )}
          <Button onClick={onCreateClick} className="h-9 w-full lg:w-auto">
            <PlusCircle className="mr-2 h-4 w-4" />
            Add New Policy
          </Button>
        </div>
      </div>

      {/* Active filters indicator */}
      {hasActiveFilters && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Filter className="h-3 w-3" />
          <span>Active filters:</span>
          {searchTerm && (
            <Badge variant="secondary" className="text-xs">
              Search: "{searchTerm}"
            </Badge>
          )}
          {statusFilter && statusFilter !== 'all' && (
            <Badge variant="secondary" className="text-xs">
              Status: {statusOptions.find(opt => opt.value === statusFilter)?.label}
            </Badge>
          )}
          {providerFilter && providerFilter !== 'all' && (
            <Badge variant="secondary" className="text-xs">
              Provider: {providers.find(p => p.id === providerFilter)?.name}
            </Badge>
          )}
          {installmentFilter && installmentFilter !== 'all' && (
            <Badge variant="secondary" className="text-xs">
              Payment: {installmentOptions.find(opt => opt.value === installmentFilter)?.label}
            </Badge>
          )}
        {hasVehicleRegOnly && (
          <Badge variant="secondary" className="text-xs">
            Has Vehicle Reg
          </Badge>
        )}
        </div>
      )}
    </div>
  );
}