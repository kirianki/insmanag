'use client';

import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRouter, useSearchParams } from 'next/navigation';
import { useDebounce } from 'use-debounce';
import { SortingState, PaginationState } from '@tanstack/react-table';

import {
  getPoliciesExtended,
  ExtendedPolicyFilterParams,
  getPolicyStatistics
} from '@/services/policyService';
import { PolicyList, PolicyStatus } from '@/types/api';

import { DataTable } from '@/components/shared/DataTable';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PoliciesToolbar } from './policies-toolbar';
import { CreatePolicyForm } from './create-policy-form';
import { columns } from './columns';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

export function PoliciesClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [isCreateOpen, setCreateOpen] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [providerFilter, setProviderFilter] = useState<string>('all');
  const [policyTypeFilter, setPolicyTypeFilter] = useState<string>('all');
  const [installmentFilter, setInstallmentFilter] = useState<string>('all');
  const [hasVehicleRegOnly, setHasVehicleRegOnly] = useState<boolean>(false);

  const [debouncedSearchTerm] = useDebounce(searchTerm, 500);
  const [sorting, setSorting] = useState<SortingState>([{ id: 'policy_end_date', desc: false }]);
  const [{ pageIndex, pageSize }, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 10,
  });

  // Build query parameters with all available filters
  const queryParams = useMemo((): ExtendedPolicyFilterParams => {
    const params: ExtendedPolicyFilterParams = {
      page: pageIndex + 1,
      page_size: pageSize,
      search: debouncedSearchTerm || undefined,
      ordering: sorting.map(s => `${s.desc ? '-' : ''}${s.id}`).join(',') || '-created_at',
    };

    // Add filters only if they have values and are not "all"
    if (statusFilter && statusFilter !== 'all') params.status = statusFilter as PolicyStatus;
    if (providerFilter && providerFilter !== 'all') params.provider__id = providerFilter;
    if (policyTypeFilter && policyTypeFilter !== 'all') params.policy_type__id = policyTypeFilter;
    if (installmentFilter && installmentFilter !== 'all') {
      params.is_installment = installmentFilter === 'installment';
    }
    // Note: no backend filter; we filter client-side later

    return params;
  }, [
    pageIndex,
    pageSize,
    debouncedSearchTerm,
    statusFilter,
    providerFilter,
    policyTypeFilter,
    installmentFilter,
    sorting,
    hasVehicleRegOnly
  ]);

  // Auto-open create dialog if create=1 in query
  React.useEffect(() => {
    const shouldOpen = searchParams.get('create') === '1';
    if (shouldOpen) {
      setCreateOpen(true);
    }
  }, [searchParams]);

  // Fetch policies with enhanced filters
  const {
    data: policiesData,
    isLoading: policiesLoading,
    isError: policiesError,
    error: policiesErrorData
  } = useQuery({
    queryKey: ['policies', queryParams],
    queryFn: () => getPoliciesExtended(queryParams),
    placeholderData: (previousData) => previousData,
  });

  // Fetch statistics for dashboard cards
  const {
    data: statisticsData,
    isLoading: statsLoading
  } = useQuery({
    queryKey: ['policy-statistics'],
    queryFn: () => getPolicyStatistics(),
  });

  const policies: PolicyList[] = (policiesData?.data?.results || []).map((p: any) => ({
    id: p.id,
    policy_number: p.policy_number,
    status: p.status?.value as PolicyStatus,
    status_display: p.status_display,
    customer_name: p.customer_detail?.name,
    provider_name: p.provider_detail?.name,
    agent_name: `${p.agent_detail?.first_name || ''} ${p.agent_detail?.last_name || ''}`.trim(),
    total_premium_amount: p.total_premium_amount,
    is_installment: p.is_installment,
    policy_start_date: p.policy_start_date,
    policy_end_date: p.policy_end_date,
    // surfaced for table column
    vehicle_registration_number: p.vehicle_registration_number,
    created_at: p.created_at,
  }));
  const pageCount = policiesData?.data?.count ? Math.ceil(policiesData.data.count / pageSize) : 0;
  const statistics = statisticsData?.data;
  const prefillCustomerId = searchParams.get('customerId') || undefined;

  // Stats loading skeleton
  const StatsSkeleton = () => (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      {[...Array(4)].map((_, i) => (
        <Card key={i}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-7 w-16 mt-1" />
          </CardContent>
        </Card>
      ))}
    </div>
  );

  const hasActiveFilters = searchTerm ||
    (statusFilter && statusFilter !== 'all') ||
    (providerFilter && providerFilter !== 'all') ||
    (policyTypeFilter && policyTypeFilter !== 'all') ||
    (installmentFilter && installmentFilter !== 'all');

  return (
    <>
      <Dialog open={isCreateOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Policy</DialogTitle>
            <DialogDescription>
              Fill in the details for the new insurance policy. All fields are required unless marked optional.
            </DialogDescription>
          </DialogHeader>
          <CreatePolicyForm
            initialCustomerId={prefillCustomerId}
            onSuccess={(newPolicy) => {
              setCreateOpen(false);
              router.push(`/policies/${newPolicy.id}`);
            }}
            onCancel={() => setCreateOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <div className="space-y-6">
        {/* Statistics Cards */}
        {statsLoading ? (
          <StatsSkeleton />
        ) : statistics && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Policies</CardTitle>
                <Badge variant="outline" className="text-xs">
                  All
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{statistics.total_policies || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Across all statuses
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Policies</CardTitle>
                <Badge variant="default" className="text-xs">
                  Live
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {(statistics.active_policies || 0) + (statistics.active_installment_policies || 0)}
                </div>
                <p className="text-xs text-muted-foreground">
                  {statistics.active_policies || 0} full, {statistics.active_installment_policies || 0} installment
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Activation</CardTitle>
                <Badge variant="secondary" className="text-xs">
                  Awaiting
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{statistics.pending_activation || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Paid but not activated
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Premium (KES)</CardTitle>
                <Badge variant="outline" className="text-xs">
                  Value
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {new Intl.NumberFormat('en-KE', {
                    style: 'currency',
                    currency: 'KES',
                  }).format(parseFloat(statistics.total_premium_value || '0'))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Total written premium
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Policies Table Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Policies</span>
              <Badge variant="outline" className="ml-2">
                {policiesData?.data?.count || 0} total
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <PoliciesToolbar
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                statusFilter={statusFilter}
                setStatusFilter={setStatusFilter}
                providerFilter={providerFilter}
                setProviderFilter={setProviderFilter}
                policyTypeFilter={policyTypeFilter}
                setPolicyTypeFilter={setPolicyTypeFilter}
                installmentFilter={installmentFilter}
                setInstallmentFilter={setInstallmentFilter}
                hasVehicleRegOnly={hasVehicleRegOnly}
                setHasVehicleRegOnly={setHasVehicleRegOnly}
                onCreateClick={() => setCreateOpen(true)}
              />

              <DataTable
                columns={columns}
                data={hasVehicleRegOnly ? policies.filter(p => !!(p as any).vehicle_registration_number) : policies}
                isLoading={policiesLoading}
                pageCount={pageCount}
                pagination={{ pageIndex, pageSize }}
                setPagination={setPagination}
                sorting={sorting}
                setSorting={setSorting}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}