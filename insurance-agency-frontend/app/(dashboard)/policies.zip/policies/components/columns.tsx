'use client';

import { ColumnDef } from '@tanstack/react-table';
import { PolicyList, PolicyStatus } from '@/types/api';
import { MoreHorizontal, Calendar, User, Building } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { useCurrentUser } from '@/lib/hooks';
import { useState } from 'react';
import { DeletePolicyDialog } from './delete-policy-dialog';

// Adjust this to change the expiring soon window globally
const EXPIRING_SOON_DAYS = 30;

const getStatusBadgeVariant = (status: PolicyStatus) => {
  switch (status) {
    case 'ACTIVE':
    case 'ACTIVE_INSTALLMENT':
      return 'default';
    case 'AWAITING_PAYMENT':
    case 'PAID_PENDING_ACTIVATION':
      return 'secondary';
    case 'EXPIRED':
    case 'CANCELLED':
      return 'destructive';
    case 'LAPSED':
      return 'outline';
    default:
      return 'secondary';
  }
};

const statusLabels: Record<PolicyStatus, string> = {
  AWAITING_PAYMENT: 'Awaiting Payment',
  PAID_PENDING_ACTIVATION: 'Pending Activation',
  ACTIVE: 'Active',
  ACTIVE_INSTALLMENT: 'Active (Installment)',
  LAPSED: 'Lapsed',
  EXPIRED: 'Expired',
  CANCELLED: 'Cancelled'
};

export const columns: ColumnDef<PolicyList>[] = [
  {
    accessorKey: 'policy_number',
    header: 'Policy Number',
    cell: ({ row }) => (
      <div className="font-mono font-medium">
        {row.getValue('policy_number')}
      </div>
    ),
  },
  {
    accessorKey: 'customer_name',
    header: 'Customer',
    cell: ({ row }) => (
      <div className="flex items-center gap-2">
        <User className="h-4 w-4 text-muted-foreground" />
        <span>{row.getValue('customer_name')}</span>
      </div>
    ),
  },
  {
    accessorKey: 'provider_name',
    header: 'Provider',
    cell: ({ row }) => (
      <div className="flex items-center gap-2">
        <Building className="h-4 w-4 text-muted-foreground" />
        <span>{row.getValue('provider_name')}</span>
      </div>
    ),
  },
  {
    accessorKey: 'vehicle_registration_number',
    header: 'Vehicle Reg',
    cell: ({ row }) => {
      const reg = row.getValue('vehicle_registration_number') as string | undefined;
      return reg ? (
        <div className="font-mono text-sm">{reg}</div>
      ) : (
        <span className="text-muted-foreground text-xs">—</span>
      );
    },
  },
  {
    accessorKey: 'status',
    header: 'Status',
    cell: ({ row }) => {
      const status = row.getValue('status') as PolicyStatus;
      return (
        <Badge variant={getStatusBadgeVariant(status)}>
          {statusLabels[status]}
        </Badge>
      );
    },
  },
  {
    accessorKey: 'total_premium_amount',
    header: 'Premium',
    cell: ({ row }) => {
      const amount = parseFloat(row.getValue('total_premium_amount'));
      return (
        <div className="font-medium text-right">
          {new Intl.NumberFormat('en-KE', {
            style: 'currency',
            currency: 'KES'
          }).format(amount)}
        </div>
      );
    },
  },
  {
    accessorKey: 'policy_end_date',
    header: 'Expires',
    cell: ({ row }) => {
      const date = new Date(row.getValue('policy_end_date'));
      const msDiff = date.getTime() - Date.now();
      const days = Math.ceil(msDiff / (1000 * 60 * 60 * 24));
      const isSoon = days >= 0 && days <= EXPIRING_SOON_DAYS;
      return (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          {date.toLocaleDateString()}
          {isSoon && (
            <Badge variant="destructive" className="ml-1">Soon</Badge>
          )}
        </div>
      );
    },
  },
  {
    id: 'actions',
    cell: ({ row }) => {
      const policy = row.original;
      const { user } = useCurrentUser();
      const [isDeleteDialogOpen, setDeleteDialogOpen] = useState(false);

      const isAgencyAdmin = user?.roles?.some(role => role.name === 'Agency Admin');
      const canDelete = !!isAgencyAdmin;

      return (
        <>
          <DeletePolicyDialog
            isOpen={isDeleteDialogOpen}
            setIsOpen={setDeleteDialogOpen}
            policyId={policy.id}
            policyNumber={policy.policy_number!}
          />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem asChild>
                <Link href={`/policies/${policy.id}`}>
                  View Details
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href={`/policies/${policy.id}/edit`}>
                  Edit Policy
                </Link>
              </DropdownMenuItem>

              {policy.status === 'PAID_PENDING_ACTIVATION' && (
                <DropdownMenuItem asChild>
                  <Link href={`/policies/${policy.id}/activate`}>
                    Activate Policy
                  </Link>
                </DropdownMenuItem>
              )}

              <DropdownMenuSeparator />

              {canDelete && (
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => setDeleteDialogOpen(true)}
                >
                  Delete Policy
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </>
      );
    },
  },
];