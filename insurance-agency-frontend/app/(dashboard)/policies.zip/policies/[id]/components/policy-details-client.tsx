// app/(dashboard)/policies/[id]/components/policy-details-client.tsx

'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Policy, PolicyStatus } from '@/types/api';
import { useToast } from '@/lib/hooks';
import { useQueryClient } from '@tanstack/react-query';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  ArrowLeft, 
  FileText, 
  CreditCard
} from 'lucide-react';

import { PolicyOverview } from './policy-overview';
import { InstallmentsTab } from './installments-tab';
import { PolicyActions } from './policy-actions';
import { ActivatePolicyDialog } from './activate-policy-dialog';
import { CancelPolicyDialog } from './cancel-policy-dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface PolicyDetailsClientProps {
  policy: Policy;
}

export function PolicyDetailsClient({ policy }: PolicyDetailsClientProps) {
  const router = useRouter();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isActivateDialogOpen, setActivateDialogOpen] = useState(false);
  const [isCancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const getStatusVariant = (status: PolicyStatus) => {
    switch (status) {
      case 'ACTIVE':
      case 'ACTIVE_INSTALLMENT':
        return 'default';
      case 'AWAITING_PAYMENT':
      case 'PAID_PENDING_ACTIVATION':
        return 'secondary';
      case 'EXPIRED':
      case 'CANCELLED':
        return 'destructive';
      case 'LAPSED':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const statusLabels: Record<PolicyStatus, string> = {
    AWAITING_PAYMENT: 'Awaiting Payment',
    PAID_PENDING_ACTIVATION: 'Pending Activation',
    ACTIVE: 'Active',
    ACTIVE_INSTALLMENT: 'Active (Installment)',
    LAPSED: 'Lapsed',
    EXPIRED: 'Expired',
    CANCELLED: 'Cancelled'
  };

  const handleEdit = () => {
    router.push(`/policies/${policy.id}/edit`);
  };

  const handleActivationSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['policies'] });
    queryClient.invalidateQueries({ queryKey: ['policy', policy.id] });
  };

  const handleCancellationSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['policies'] });
    queryClient.invalidateQueries({ queryKey: ['policy', policy.id] });
  };

  if (!policy) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  return (
    <>
      <ActivatePolicyDialog
        policy={policy}
        isOpen={isActivateDialogOpen}
        setIsOpen={setActivateDialogOpen}
        onSuccess={handleActivationSuccess}
      />

      <CancelPolicyDialog
        policy={policy}
        isOpen={isCancelDialogOpen}
        setIsOpen={setCancelDialogOpen}
        onSuccess={handleCancellationSuccess}
      />

      <div className="space-y-6">
        {/* Header with actions */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => router.push('/policies')}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Policies
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">
                Policy #{policy.policy_number}
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant={getStatusVariant(policy.status.value)}>
                  {statusLabels[policy.status.value]}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  for {policy.customer_detail.name}
                </span>
              </div>
            </div>
          </div>

          <PolicyActions
            policy={policy}
            onEdit={handleEdit}
            onActivate={() => setActivateDialogOpen(true)}
            onCancel={() => setCancelDialogOpen(true)}
          />
        </div>

        {/* Main content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Activation / Renewal callouts */}
          {policy.status.value === 'PAID_PENDING_ACTIVATION' && (
            <Alert>
              <AlertDescription>
                This policy is paid and pending activation. Click "Activate" to issue the certificate.
              </AlertDescription>
            </Alert>
          )}
          {policy.status.value === 'ACTIVE' || policy.status.value === 'ACTIVE_INSTALLMENT' ? (
            (() => {
              const end = new Date(policy.policy_end_date).getTime();
              const days = Math.ceil((end - Date.now()) / (1000 * 60 * 60 * 24));
              return days >= 0 && days <= 30 ? (
                <Alert>
                  <AlertDescription>
                    This policy expires in {days} day{days === 1 ? '' : 's'}. Consider initiating renewal.
                  </AlertDescription>
                </Alert>
              ) : null;
            })()
          ) : null}
          <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:inline-flex">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="installments" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Installments
              {policy.is_installment && (
                <Badge variant="outline" className="ml-1 text-xs">
                  {policy.installments?.length || 0}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <PolicyOverview policy={policy} />
          </TabsContent>

          <TabsContent value="installments" className="space-y-6">
            <InstallmentsTab policy={policy} />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}