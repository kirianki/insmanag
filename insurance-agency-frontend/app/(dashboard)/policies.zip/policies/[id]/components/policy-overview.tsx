// app/(dashboard)/policies/[id]/components/policy-overview.tsx

'use client';

import React from 'react';
import { Policy } from '@/types/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, User, Building, FileText, CreditCard, Car } from 'lucide-react';
import { format } from 'date-fns';

interface PolicyOverviewProps {
  policy: Policy;
}

export function PolicyOverview({ policy }: PolicyOverviewProps) {
  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(parseFloat(amount));
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'PPP');
  };

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {/* Policy Details */}
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Policy Details
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Policy Number
              </label>
              <p className="font-mono font-medium">{policy.policy_number}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Status
              </label>
              <div className="flex items-center gap-2">
                <Badge variant={
                  policy.status.value === 'ACTIVE' || policy.status.value === 'ACTIVE_INSTALLMENT' 
                    ? 'default' 
                    : policy.status.value === 'CANCELLED' || policy.status.value === 'EXPIRED'
                    ? 'destructive'
                    : 'secondary'
                }>
                  {policy.status.label}
                </Badge>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Total Premium
              </label>
              <p className="font-medium">{formatCurrency(policy.total_premium_amount)}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Payment Type
              </label>
              <p className="font-medium flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                {policy.is_installment ? 'Installment Plan' : 'Full Payment'}
              </p>
            </div>
          </div>

          {policy.vehicle_registration_number && (
            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Vehicle Registration
              </label>
              <p className="font-medium flex items-center gap-2">
                <Car className="h-4 w-4" />
                {policy.vehicle_registration_number}
              </p>
            </div>
          )}

          {policy.insurance_certificate_number && (
            <div>
              <label className="text-sm font-medium text-muted-foreground">
                Insurance Certificate
              </label>
              <p className="font-mono font-medium">{policy.insurance_certificate_number}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dates */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Policy Period
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Start Date
            </label>
            <p className="font-medium">{formatDate(policy.policy_start_date)}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              End Date
            </label>
            <p className="font-medium">{formatDate(policy.policy_end_date)}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Created
            </label>
            <p className="font-medium">{formatDate(policy.created_at)}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Last Updated
            </label>
            <p className="font-medium">{formatDate(policy.updated_at)}</p>
          </div>
        </CardContent>
      </Card>

      {/* Customer Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Customer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Name
            </label>
            <p className="font-medium">{policy.customer_detail.name}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Phone
            </label>
            <p className="font-medium">{policy.customer_detail.phone}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Customer ID
            </label>
            <p className="font-mono text-sm">{policy.customer}</p>
          </div>
        </CardContent>
      </Card>

      {/* Agent & Provider */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Agent & Provider
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Assigned Agent
            </label>
            <p className="font-medium">
              {policy.agent_detail.first_name} {policy.agent_detail.last_name}
            </p>
            <p className="text-sm text-muted-foreground">{policy.agent_detail.email}</p>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Insurance Provider
            </label>
            <p className="font-medium">{policy.provider_detail.name}</p>
            {policy.provider_detail.short_name && (
              <p className="text-sm text-muted-foreground">{policy.provider_detail.short_name}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground">
              Policy Type
            </label>
            <p className="font-medium">{policy.policy_type_detail.name}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}