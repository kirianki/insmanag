'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import {
  createPolicyEnhanced,
  getCreatePolicyDropdownData,
  CreatePolicyRequest,
  quickCreateCustomer,
} from '@/services/policyService';
import { Policy, PolicyType } from '@/types/api';
import { useToast } from '@/lib/hooks';
import { useAuth } from '@/lib/auth'; // Changed from useCurrentUser to useAuth

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Plus, Trash2, UserIcon, Building, FileText, CreditCard, Search, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

const formSchema = z.object({
    customer: z.string().uuid({ message: "Please select a customer" }),
    agent: z.string().uuid({ message: "Agent is required" }),
    provider: z.string().uuid({ message: "Please select an insurance provider" }),
    policy_type: z.string().uuid({ message: "Please select a policy type" }),
    total_premium_amount: z.coerce.number().positive({ message: "Premium must be a positive number" }),
    policy_start_date: z.date({ required_error: "Start date is required" }),
    policy_end_date: z.date({ required_error: "End date is required" }),
    vehicle_registration_number: z.string().optional(),
    is_installment: z.boolean().default(false),
    installment_plan: z.array(z.object({
      due_date: z.date({ required_error: "Due date is required" }),
      amount: z.coerce.number().positive({ message: "Amount must be positive" }),
    })).optional(),
  }).refine(
    (data) => data.policy_end_date > data.policy_start_date,
    {
      message: "End date must be after start date",
      path: ["policy_end_date"],
    }
  ).refine(
    (data) => {
      if (data.is_installment && data.installment_plan) {
        const totalInstallments = data.installment_plan.reduce((sum, item) => sum + item.amount, 0);
        return Math.abs(totalInstallments - data.total_premium_amount) < 0.01;
      }
      return true;
    },
    {
      message: "Sum of installment amounts must equal total premium amount",
      path: ["installment_plan"],
    }
  );

const quickCustomerSchema = z.object({
    first_name: z.string().min(1, "First name is required"),
    last_name: z.string().min(1, "Last name is required"),
    email: z.string().email().optional().or(z.literal('')),
    phone: z.string().min(1, "Phone number is required"),
    id_number: z.string().optional(),
});

interface CreatePolicyFormProps {
  onSuccess: (newPolicy: Policy) => void;
  onCancel: () => void;
  initialCustomerId?: string;
}

const FormSkeleton = () => (
    <div className="space-y-6 p-1">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
      <Skeleton className="h-10 w-32 ml-auto" />
    </div>
);

export function CreatePolicyForm({ onSuccess, onCancel, initialCustomerId }: CreatePolicyFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isLoading: authLoading } = useAuth(); // Changed to useAuth
  const [selectedPolicyType, setSelectedPolicyType] = useState<PolicyType | null>(null);
  const [isQuickCustomerOpen, setIsQuickCustomerOpen] = useState(false);
  const [customerSearch, setCustomerSearch] = useState('');

  // Enhanced debug logging
  console.log("=== CREATE POLICY FORM DEBUG ===");
  console.log("User object:", user);
  console.log("User ID:", user?.id);
  console.log("Agency detail:", user?.agency_detail);
  console.log("Agency ID:", user?.agency_detail?.id);
  console.log("User roles:", user?.roles);
  console.log("Is authenticated:", !!user);
  console.log("Auth loading:", authLoading);
  console.log("=== END DEBUG ===");

  // Get agency ID from user - handle different possible structures
  const getAgencyId = () => {
    if (!user) return null;
    
    // Try different possible paths to agency ID
    const agencyId = 
      user.agency_detail?.id || 
      user.agency || 
      (user as any).agency_id;
    
    console.log("Resolved agency ID:", agencyId);
    return agencyId;
  };

  const agencyId = getAgencyId();

  // Wait for user to be loaded before making the query
  const { 
    data: dropdownData, 
    isLoading: dropdownLoading, 
    error: dropdownError, 
    refetch 
  } = useQuery({
    queryKey: ['create-policy-dropdown', agencyId],
    queryFn: () => {
      if (!agencyId) {
        throw new Error("No agency ID available");
      }
      console.log("Making API call with agency ID:", agencyId);
      return getCreatePolicyDropdownData(agencyId);
    },
    enabled: !!agencyId && !!user, // Only enable if we have both user and agency ID
    retry: 2,
  });

  // Debug dropdown data and loading states
  useEffect(() => {
    console.log("=== DROPDOWN STATE DEBUG ===");
    console.log("Auth loading:", authLoading);
    console.log("Dropdown loading:", dropdownLoading);
    console.log("Dropdown error:", dropdownError);
    console.log("Dropdown data:", dropdownData);
    console.log("Has agency ID:", !!agencyId);
    console.log("Has user:", !!user);
    console.log("Query enabled:", !!agencyId && !!user);
    console.log("=== END DROPDOWN DEBUG ===");
  }, [authLoading, dropdownLoading, dropdownError, dropdownData, agencyId, user]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      is_installment: false,
      installment_plan: [],
      policy_start_date: new Date(),
      policy_end_date: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
      agent: user?.id || '',
      vehicle_registration_number: '',
      customer: initialCustomerId || '',
      provider: '',
      policy_type: '',
      total_premium_amount: 0,
    },
  });

  const quickCustomerForm = useForm<z.infer<typeof quickCustomerSchema>>({
    resolver: zodResolver(quickCustomerSchema),
    defaultValues: { first_name: '', last_name: '', email: '', phone: '', id_number: '' },
  });

  const watchedPolicyType = form.watch('policy_type');
  const watchedIsInstallment = form.watch('is_installment');
  const watchedInstallmentPlan = form.watch('installment_plan');
  const watchedTotalPremium = form.watch('total_premium_amount');

  useEffect(() => {
    if (watchedPolicyType && dropdownData?.policyTypes) {
      const policyType = dropdownData.policyTypes.find(pt => pt.id === watchedPolicyType);
      setSelectedPolicyType(policyType || null);
    } else {
      setSelectedPolicyType(null);
    }
  }, [watchedPolicyType, dropdownData?.policyTypes]);

  useEffect(() => {
    if (user?.id) {
      form.setValue('agent', user.id);
    }
  }, [user?.id, form]);

  // Keep customer in sync when initialCustomerId is provided
  useEffect(() => {
    if (initialCustomerId) {
      form.setValue('customer', initialCustomerId);
    }
  }, [initialCustomerId, form]);

  const filteredCustomers = dropdownData?.customers?.filter(customer =>
    customerSearch === '' ||
    `${customer.first_name} ${customer.last_name}`.toLowerCase().includes(customerSearch.toLowerCase()) ||
    customer.phone.includes(customerSearch) ||
    (customer.email && customer.email.toLowerCase().includes(customerSearch.toLowerCase()))
  ) || [];

  const mutation = useMutation({
    mutationFn: (values: z.infer<typeof formSchema>) => {
      const payload: CreatePolicyRequest = {
        ...values,
        total_premium_amount: values.total_premium_amount.toString(),
        policy_start_date: format(values.policy_start_date, 'yyyy-MM-dd'),
        policy_end_date: format(values.policy_end_date, 'yyyy-MM-dd'),
        installment_plan: values.is_installment && values.installment_plan ? values.installment_plan.map(installment => ({
          due_date: format(installment.due_date, 'yyyy-MM-dd'),
          amount: Number(installment.amount).toString(),
        })) : undefined,
      };
      return createPolicyEnhanced(payload);
    },
    onSuccess: (response) => {
      toast.success("Policy Created", { description: "The new policy has been successfully created." });
      queryClient.invalidateQueries({ queryKey: ['policies'] });
      queryClient.invalidateQueries({ queryKey: ['policy-statistics'] });
      onSuccess(response.data);
    },
    onError: (err: any) => {
      console.error('Policy creation error:', err);
      const errorDetail = err.response?.data;
      if (errorDetail) {
        if (typeof errorDetail === 'object') {
          const fieldErrors = Object.entries(errorDetail).map(([field, messages]) => `${field}: ${Array.isArray(messages) ? messages.join(', ') : messages}`).join('; ');
          toast.error("Creation Failed", { description: fieldErrors || "Please check the form for errors." });
        } else {
          toast.error("Creation Failed", { description: errorDetail.detail || errorDetail.message || "An error occurred while creating the policy." });
        }
      } else {
        toast.error("Creation Failed", { description: "An error occurred while creating the policy. Please try again." });
      }
    }
  });

  const quickCustomerMutation = useMutation({
    mutationFn: (data: z.infer<typeof quickCustomerSchema>) => quickCreateCustomer(data),
    onSuccess: (response) => {
      toast.success("Customer Created", { description: "Customer has been created successfully." });
      refetch();
      form.setValue('customer', response.data.id);
      setIsQuickCustomerOpen(false);
      quickCustomerForm.reset();
    },
    onError: (err: any) => {
      console.error('Customer creation error:', err);
      toast.error("Customer Creation Failed", { description: err.response?.data?.detail || "Failed to create customer. Please try again." });
    }
  });

  const addInstallment = () => {
    const currentInstallments = form.getValues('installment_plan') || [];
    const lastDueDate = currentInstallments.length > 0 ? new Date(currentInstallments[currentInstallments.length - 1].due_date) : new Date();
    const nextDueDate = new Date(lastDueDate);
    nextDueDate.setMonth(nextDueDate.getMonth() + 1);
    form.setValue('installment_plan', [...currentInstallments, { due_date: nextDueDate, amount: 0 }]);
  };

  const removeInstallment = (index: number) => {
    const currentInstallments = form.getValues('installment_plan') || [];
    form.setValue('installment_plan', currentInstallments.filter((_, i) => i !== index));
  };

  const remainingAmount = watchedInstallmentPlan?.reduce((sum, item) => sum - (item.amount || 0), watchedTotalPremium || 0) || 0;
  const onSubmit = (values: z.infer<typeof formSchema>) => { mutation.mutate(values); };
  const onQuickCustomerSubmit = (values: z.infer<typeof quickCustomerSchema>) => { quickCustomerMutation.mutate(values); };

  // Show loading if auth is loading OR dropdown is loading
  if (authLoading) {
    console.log("Auth still loading, showing skeleton");
    return <FormSkeleton />;
  }

  if (dropdownLoading) {
    console.log("Dropdown data loading, showing skeleton");
    return <FormSkeleton />;
  }

  // Show error if no user (not authenticated)
  if (!user) {
    console.log("No user available - not authenticated");
    return (
      <div className="text-center py-8">
        <p className="text-destructive mb-4">You must be logged in to create a policy.</p>
        <Button variant="outline" onClick={() => window.location.href = '/login'}>
          Go to Login
        </Button>
      </div>
    );
  }

  // Show error if no agency ID
  if (!agencyId) {
    console.log("No agency ID available");
    return (
      <div className="text-center py-8">
        <p className="text-destructive mb-4">Unable to determine your agency.</p>
        <div className="space-y-2 text-sm text-muted-foreground mb-4">
          <p>Please contact your administrator or ensure your account is properly configured.</p>
          <p>User ID: {user?.id}</p>
          <p>Agency available: {!!user?.agency_detail ? 'Yes' : 'No'}</p>
        </div>
        <Button variant="outline" onClick={() => window.location.reload()}>Refresh Page</Button>
      </div>
    );
  }

  // Show error if dropdown failed to load
  if (dropdownError) {
    console.error('Dropdown error:', dropdownError);
    return (
      <div className="text-center py-8">
        <p className="text-destructive mb-4">Failed to load form data. Please try again.</p>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>Debug info:</p>
          <p>User: {user ? 'Loaded' : 'Not loaded'}</p>
          <p>Agency ID: {agencyId || 'Not available'}</p>
          <p>Error: {dropdownError.message}</p>
        </div>
        <Button variant="outline" onClick={() => refetch()} className="mt-4">Retry</Button>
      </div>
    );
  }

  // Show warning if no data is available
  if (!dropdownData?.customers?.length || !dropdownData?.providers?.length || !dropdownData?.policyTypes?.length) {
    return (
      <div className="text-center py-8">
        <p className="text-destructive mb-4">Incomplete data for policy creation.</p>
        <div className="space-y-2 text-sm text-muted-foreground mb-4">
          <p>Available data:</p>
          <p>Customers: {dropdownData?.customers?.length || 0}</p>
          <p>Providers: {dropdownData?.providers?.length || 0}</p>
          <p>Policy Types: {dropdownData?.policyTypes?.length || 0}</p>
        </div>
        <Button variant="outline" onClick={() => refetch()}>Retry</Button>
      </div>
    );
  }

  return (
    <>
      <Dialog open={isQuickCustomerOpen} onOpenChange={setIsQuickCustomerOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Quick Add Customer</DialogTitle>
            <DialogDescription>
              Create a new customer quickly to proceed with policy creation.
            </DialogDescription>
          </DialogHeader>
          <Form {...quickCustomerForm}>
            <form onSubmit={quickCustomerForm.handleSubmit(onQuickCustomerSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={quickCustomerForm.control}
                  name="first_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={quickCustomerForm.control}
                  name="last_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={quickCustomerForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email (Optional)</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={quickCustomerForm.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={quickCustomerForm.control}
                name="id_number"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ID Number (Optional)</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsQuickCustomerOpen(false)}
                  disabled={quickCustomerMutation.isPending}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={quickCustomerMutation.isPending}>
                  {quickCustomerMutation.isPending ? "Creating..." : "Create Customer"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 p-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Policy Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Customer Field */}
              <FormField
                control={form.control}
                name="customer"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <UserIcon className="h-4 w-4" />
                      Customer
                      {!dropdownData.customers.length && (
                        <Badge variant="destructive" className="text-xs ml-2">
                          No customers found
                        </Badge>
                      )}
                    </FormLabel>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                          <Input
                            placeholder="Search customers..."
                            value={customerSearch}
                            onChange={(e) => setCustomerSearch(e.target.value)}
                            className="pl-8"
                            disabled={!!initialCustomerId}
                          />
                        </div>
                        {!initialCustomerId && (
                          <Button type="button" variant="outline" onClick={() => setIsQuickCustomerOpen(true)}>
                            <Plus className="h-4 w-4 mr-1" />
                            New
                          </Button>
                        )}
                      </div>
                      <Select onValueChange={field.onChange} value={field.value} disabled={!!initialCustomerId}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {filteredCustomers.map((customer) => (
                            <SelectItem key={customer.id} value={customer.id}>
                              {customer.first_name} {customer.last_name} - {customer.phone}
                            </SelectItem>
                          ))}
                          {filteredCustomers.length === 0 && (
                            <div className="p-2 text-sm text-muted-foreground text-center">
                              {customerSearch ? 'No customers match your search' : 'No customers available'}
                            </div>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Agent Field - Fixed to show current user */}
              <FormField
                control={form.control}
                name="agent"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Lock className="h-4 w-4" />
                      Agent
                    </FormLabel>
                    <FormControl>
                      <div className="flex items-center gap-2 p-2 border rounded-md bg-muted/50 h-10">
                        <UserIcon className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm">
                          {user.first_name} {user.last_name} (You)
                        </span>
                      </div>
                    </FormControl>
                    <FormDescription>
                      Policies are automatically assigned to you.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Provider Field */}
                <FormField
                  control={form.control}
                  name="provider"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Building className="h-4 w-4" />
                        Insurance Provider
                        {!dropdownData.providers.length && (
                          <Badge variant="destructive" className="text-xs ml-2">
                            No providers
                          </Badge>
                        )}
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a provider" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownData.providers.map((provider) => (
                            <SelectItem key={provider.id} value={provider.id}>
                              {provider.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Policy Type Field */}
                <FormField
                  control={form.control}
                  name="policy_type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        Policy Type
                        {!dropdownData.policyTypes.length && (
                          <Badge variant="destructive" className="text-xs ml-2">
                            No types
                          </Badge>
                        )}
                      </FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select policy type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dropdownData.policyTypes.map((type) => (
                            <SelectItem key={type.id} value={type.id}>
                              <div className="flex items-center justify-between w-full">
                                <span>{type.name}</span>
                                {type.requires_vehicle_reg && (
                                  <Badge variant="outline" className="ml-2 text-xs">
                                    Vehicle
                                  </Badge>
                                )}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Vehicle Registration - Conditionally shown */}
              {selectedPolicyType?.requires_vehicle_reg && (
                <FormField
                  control={form.control}
                  name="vehicle_registration_number"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vehicle Registration</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., KAA123A" {...field} />
                      </FormControl>
                      <FormDescription>
                        Required for {selectedPolicyType.name}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* Premium Amount */}
              <FormField
                control={form.control}
                name="total_premium_amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Premium Amount</FormLabel>
                    <FormControl>
                      <Input type="number" step="0.01" placeholder="0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Dates */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="policy_start_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Policy Start Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="policy_end_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Policy End Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Installment Plan */}
              <FormField
                control={form.control}
                name="is_installment"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base flex items-center gap-2">
                        <CreditCard className="h-4 w-4" />
                        Installment Payment Plan
                      </FormLabel>
                      <FormDescription>
                        Enable to split premium into multiple payments
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {watchedIsInstallment && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <FormLabel>Installment Plan</FormLabel>
                    <Button type="button" variant="outline" size="sm" onClick={addInstallment}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Installment
                    </Button>
                  </div>
                  
                  {watchedInstallmentPlan?.map((installment, index) => (
                    <div key={index} className="flex items-end gap-2">
                      <FormField
                        control={form.control}
                        name={`installment_plan.${index}.due_date`}
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormLabel>Due Date</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={cn(
                                      "w-full pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "PPP")
                                    ) : (
                                      <span>Pick a date</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  disabled={(date) => date < new Date()}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`installment_plan.${index}.amount`}
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormLabel>Amount</FormLabel>
                            <FormControl>
                              <Input type="number" step="0.01" placeholder="0.00" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={() => removeInstallment(index)}
                        className="mb-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {remainingAmount !== 0 && !isNaN(remainingAmount) && (
                    <div className={cn(
                      "text-sm p-2 rounded",
                      remainingAmount > 0 ? "bg-yellow-50 text-yellow-800" : "bg-red-50 text-red-800"
                    )}>
                      {remainingAmount > 0 
                        ? `Remaining amount to allocate: ${Number(remainingAmount).toFixed(2)}`
                        : `Over-allocated by: ${Math.abs(Number(remainingAmount)).toFixed(2)}`
                      }
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? "Creating..." : "Create Policy"}
            </Button>
          </div>
        </form>
      </Form>
    </>
  );
}