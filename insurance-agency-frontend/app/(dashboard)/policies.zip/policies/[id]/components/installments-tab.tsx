// app/(dashboard)/policies/[id]/components/installments-tab.tsx

'use client';

import React from 'react';
import { Policy, PolicyInstallment, PolicyInstallmentStatus } from '@/types/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, CreditCard, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

interface InstallmentsTabProps {
  policy: Policy;
}

export function InstallmentsTab({ policy }: InstallmentsTabProps) {
  if (!policy.is_installment) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Payment Information
          </CardTitle>
          <CardDescription>
            This policy was paid in full upfront.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8 text-muted-foreground">
            <div className="text-center">
              <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>Full payment received</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getInstallmentStatusIcon = (status?: PolicyInstallmentStatus) => {
    switch (status) {
      case 'PAID':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'OVERDUE':
        return <AlertTriangle className="h-4 w-4 text-destructive" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getInstallmentStatusVariant = (status?: PolicyInstallmentStatus) => {
    switch (status) {
      case 'PAID':
        return 'default';
      case 'OVERDUE':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES'
    }).format(parseFloat(amount));
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'PPP');
  };

  const paidInstallments = policy.installments?.filter(i => i.status === 'PAID') || [];
  const pendingInstallments = policy.installments?.filter(i => i.status !== 'PAID') || [];
  const totalPaid = paidInstallments.reduce((sum, i) => sum + parseFloat(i.amount), 0);
  const totalPending = pendingInstallments.reduce((sum, i) => sum + parseFloat(i.amount), 0);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Premium</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(policy.total_premium_amount)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paid</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(totalPaid.toString())}
            </div>
            <p className="text-xs text-muted-foreground">
              {paidInstallments.length} of {policy.installments?.length} installments
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(totalPending.toString())}
            </div>
            <p className="text-xs text-muted-foreground">
              {pendingInstallments.length} installments remaining
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Installments List */}
      <Card>
        <CardHeader>
          <CardTitle>Installment Plan</CardTitle>
          <CardDescription>
            Payment schedule for this policy
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {policy.installments?.map((installment, index) => (
              <div
                key={installment.id}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    {getInstallmentStatusIcon(installment.status)}
                    <Badge variant={getInstallmentStatusVariant(installment.status)}>
                      {installment.status_display}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    {formatDate(installment.due_date)}
                  </div>

                  <div className="font-medium">
                    Installment #{index + 1}
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="font-medium">
                      {formatCurrency(installment.amount)}
                    </div>
                    {installment.paid_on && (
                      <div className="text-xs text-muted-foreground">
                        Paid on {formatDate(installment.paid_on)}
                      </div>
                    )}
                  </div>

                  {installment.status !== 'PAID' && (
                    <Button variant="outline" size="sm">
                      Mark as Paid
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}